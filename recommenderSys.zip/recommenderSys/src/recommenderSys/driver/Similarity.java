package recommenderSys.driver;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Map;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;

public class Similarity {
	FileProcessor fp = null;
	public int[][] data;
	private Map<Integer,ArrayList<Integer>> mylist;
	int users=0;
	int items=0;
	int neighbours = 30;
	public String outfilename;
	double cosinedistances[][];

	/*
	 * Constructor
	 */
	public Similarity(int data[][],FileProcessor fp,String outfilename){
		this.data = data;
		mylist = new LinkedHashMap<Integer,ArrayList<Integer>>();
		this.items = fp.items;
		this.users = fp.users;
		this.outfilename = outfilename;
		cosinedistances = new double[users][users];
	}
	
	
	/*
	 * To find Similarity and Neighbors of users
	 */
	public void CosineSimilarity(int data[][]){
		
			//Mylist map used To find user-item whose rating is to be predicted
			for(int j=0;j<users;j++){
				for(int i=0;i<items;i++)
				{
				if(data[i][j] == 0)
				{
					if(!mylist.containsKey(j+1)){
						mylist.put(j+1, new ArrayList<Integer>());
						mylist.get(j+1).add(i+1);
					}
					else
						mylist.get(j+1).add(i+1);
				}
			}
		}

		//To find Cosined distances between users
		CosinedDistances();

		//Finding nearest neighbours
		Map<Integer,ArrayList<NodeForlist>> MaplistNeighbours = new LinkedHashMap<Integer,ArrayList<NodeForlist>>(); ;
		NodeForlist n=null;
		for(int i=0;i<users;i++)
		{
			for(int j=0;j<users;j++)
			{
					n= new NodeForlist(j, cosinedistances[i][j]);
					if(!MaplistNeighbours.containsKey(i)){
						MaplistNeighbours.put(i,new ArrayList<NodeForlist>());
						MaplistNeighbours.get(i).add(n);
					}
					else{
						MaplistNeighbours.get(i).add(n);
					}
			}
		}
		
//		Finding Nearest Neighbours
		Map<Integer,ArrayList<Integer>> MaplistNeighboursFinal = new LinkedHashMap<Integer,ArrayList<Integer>>();
		for (Map.Entry<Integer, ArrayList<NodeForlist>> entry : MaplistNeighbours.entrySet()) {
			Integer key = entry.getKey();
			ArrayList<NodeForlist> value = entry.getValue();
			Collections.sort(value);
			ArrayList<Integer> NeighbourListtemp = new ArrayList<Integer>();
			Iterator<NodeForlist> iter = value.iterator();
			while(iter.hasNext())
			{
			    NodeForlist nd = iter.next();
			    NeighbourListtemp.add(nd.position);
			}
			
			ArrayList<Integer> NeighbourList = new ArrayList<>(NeighbourListtemp.subList(0, neighbours));
			MaplistNeighboursFinal.put(key, new ArrayList<Integer>());
			
			for(int m=0;m < NeighbourList.size();m++){
				MaplistNeighboursFinal.get(key).add(NeighbourList.get(m));
			}
			ArrayList<Integer> value1 = MaplistNeighboursFinal.get(key);
		}
			
		FinalFormula(MaplistNeighboursFinal,cosinedistances);
	}
	/*
	 *To calculate the prediction for the user-item pair by performing a weighted average of deviations from the neighbor's mean 
	 */
	public void FinalFormula(Map<Integer,ArrayList<Integer>> MaplistNeighboursFinal, double cosinedistances[][]){
		
		//Average rating for each user
		double avgratingofallUsers[] =new double[users];
		int countNonzero=0;
				for(int i=0;i<users;i++)
				{
					int sum =0;
					countNonzero=0;
					for(int j=0;j<items;j++)
					{
						if(data[j][i] != 0){
						sum = sum + data[j][i];
						countNonzero++;
						}
					}
					avgratingofallUsers[i] = sum/countNonzero;
				}
		
		//Weighted Formula for prediction	
		for (Map.Entry<Integer, ArrayList<Integer>> entry : mylist.entrySet()) {
			double Ratings=0;
			double Numr =0;
			double WeightedSummation = 0;
			double predictedValue = 0;
			Integer key = entry.getKey();
			ArrayList<Integer> value = entry.getValue();
			for(Integer temp : value){
				double RatingMul=0;
				ArrayList<Integer> TotalNeighboursForKey = new ArrayList<Integer>();
				TotalNeighboursForKey  = MaplistNeighboursFinal.get(key-1);
				for(Integer tempNeighForKey : TotalNeighboursForKey){

					if(data[temp-1][tempNeighForKey]!=0){
						Ratings = data[temp-1][tempNeighForKey] - avgratingofallUsers[tempNeighForKey];
						RatingMul += Ratings * cosinedistances[key-1][tempNeighForKey];
						WeightedSummation += cosinedistances[key-1][tempNeighForKey];
					}
					
				}
				Numr = RatingMul;
				predictedValue  =  avgratingofallUsers[key-1] + Numr/WeightedSummation;
				data[temp-1][key-1] = (int) Math.round(predictedValue);
			}

		} 
			
	}

	/*
	 * To find Cosined distances between users
	 */
	public void CosinedDistances(){
		for(int i=0;i<users;i++){
			for(int j=0;j<users;j++){
				cosinedistances[i][j] = -1;
			}
		}
		
		//Calculate Numerator
		double norm[] = new double[users];
		for(int u=0;u<users;u++){
			norm[u] = 0;
			for(int i=0;i<items;i++){
				norm[u] += data[i][u] * data[i][u];
			}
			norm[u] = Math.sqrt(norm[u]);
		}

		//Calculate Denominator and final Cosined distance
		double dot_product=0;
		for(int u=0;u<users;u++)
		{
			for(int us=u+1;us<users;us++)
			{
				dot_product  = 0;
				for(int i=0;i<items;i++)
				{
					if(cosinedistances[u][us] == -1)
						dot_product += data[i][u] * data[i][us]; 
				}

				double value = (norm[u] * norm[us]);
				cosinedistances[u][us] = dot_product/value;
				cosinedistances[us][u] = dot_product/value;
				
			}
		}
	}

	/*
	 * To display the output to the file
	 */
	public void Display(){
		BufferedWriter output =null;
		try {
			output = new BufferedWriter(new FileWriter(outfilename));
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
			for(int u=0;u<users;u++){
				for(int i = 0;i<items;i++){
				try {
					String user = Integer.toString(u+1);
					String item = Integer.toString(i+1);
					int temp = data[i][u];
					if(temp==0)
						temp=1;
					String value= Integer.toString(temp);
					output.write(user);
					output.write(" ");
					output.write(item);
					output.write(" ");
					output.write(value);
					output.newLine();
					output.flush();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		}

	}
}