package recommenderSys.driver;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.util.Scanner;

public class FileProcessor {

	private BufferedWriter output=null;
	private String inputfilename;
	public String outputfilename;
	public int items = 1682;
	public int users = 943;
	int data[][] = new int [items][users];
	
	
	public FileProcessor(String inputfilename,String outfilename)
	{
		this.inputfilename = inputfilename; 		
		this.outputfilename = outfilename;
		
	}
	/*
	 * To read from file
	 */

	public int[][] ReadfromFileInMatrix()
	{
		String temp[] =null; 
		File f = new File(this.inputfilename);
		if(f.length()==0)
		{
			System.out.println("File is empty");
		}
		else
		{
		Scanner br=null;
    	FileReader reader=null;	
		try{
				reader=new FileReader(f);
				br = new Scanner(reader);
				String textLine = "";
		
				for(int i=0;i<items;i++)
				{
					for(int j=0;j<users;j++)
					{
						data[i][j] = 0;
					}
				}
				
				while(br.hasNextLine()){
					textLine = br.nextLine();
					temp = textLine.split(" ");
					data[Integer.parseInt(temp[1]) - 1][Integer.parseInt(temp[0]) - 1] = Integer.parseInt(temp[2]);
				}
		}catch(Exception E){
				E.printStackTrace();
				System.out.println("Exception: file operation");
			}
		   finally
		   {
			   br.close();
		   }
		}
		return data;
	}
}