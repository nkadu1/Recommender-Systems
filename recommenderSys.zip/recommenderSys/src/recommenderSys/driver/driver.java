package recommenderSys.driver;

public class driver {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileProcessor fp = new FileProcessor("train_all_txt.txt","output.txt"); 
		int data [][] = fp.ReadfromFileInMatrix();
		Similarity sm = new Similarity(data,fp,fp.outputfilename);
		sm.CosineSimilarity(data);
		sm.Display();
	}
}