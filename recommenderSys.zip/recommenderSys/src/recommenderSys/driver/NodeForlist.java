package recommenderSys.driver;

/*
 * Class To Handle data to calculate k-neighbor's
 */
public class NodeForlist implements Comparable{
	
	//To save user position and its cosined distances
	double value=0;
	int position=0;
	
	public NodeForlist (int position,double value){
		this.position = position;
		this.value= value;
	}
	
	/*
	 * To sort
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		NodeForlist n = (NodeForlist) o;
		double comparevalue = ((NodeForlist)n).value;
	    double res =  comparevalue - this.value ;
	        if(res > 0.00001) return 1;
	        if(res < -0.00001) return -1;
	        return 0;
	}
	
	@Override
    public String toString() {
        return "[ position =" + position + ", value=" + value + "]";
    }
	
}
